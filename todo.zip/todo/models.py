from django.db import models
from django.contrib.auth.models import User  # Import User model

class Todo(models.Model):
    title = models.CharField(max_length=100)  # Task title
    description = models.TextField(blank=True, null=True)  # Optional description
    deadline = models.DateField()  # Task deadline
    completed = models.BooleanField(default=False)  # Task completion status
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Add user field

    def __str__(self):
        return self.title
