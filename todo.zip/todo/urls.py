from django.urls import path
from . import views
from django.contrib.auth import views as auth_views  # For login/logout views

urlpatterns = [
    # Basic CRUD URLs
    path('', views.todo_list, name='todo_list'),  # List all tasks
    path('add/', views.add_todo, name='add_todo'),  # Add a new task
    path('edit/<int:id>/', views.edit_todo, name='edit_todo'),  # Edit an existing task
    path('delete/<int:id>/', views.delete_todo, name='delete_todo'),  # Delete a task

    # Advanced Functionality URLs
    path('toggle/<int:id>/', views.toggle_complete, name='toggle_complete'),  # Toggle task completion

    # User Authentication URLs
    path('login/', auth_views.LoginView.as_view(template_name='todo/login.html'), name='login'),  # Login page
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),  # Logout functionality
]
