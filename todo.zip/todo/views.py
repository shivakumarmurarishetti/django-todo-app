from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login

from .forms import TodoForm
from .models import Todo
from .forms import LoginForm

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('todo_list')  # Redirect to the todo list page after login
            else:
                form.add_error(None, "Invalid username or password")
    else:
        form = LoginForm()

    return render(request, 'todo/login.html', {'form': form})
# View to display all tasks (optional login protection)
def todo_list(request):
    todos = Todo.objects.all()
    if request.user.is_authenticated:
        todos = todos.filter(user=request.user)
    return render(request, 'todo/todo_list.html', {'todos': todos})

# Add a new task (requires login)
@login_required
def add_todo(request):
    if request.method == 'POST':
        form = TodoForm(request.POST)
        if form.is_valid():
            todo = form.save(commit=False)
            todo.user = request.user  # Associate task with logged-in user
            todo.save()
            return redirect('todo_list')
    else:
        form = TodoForm()
    return render(request, 'todo/add_todo.html', {'form': form})

# Edit an existing task (requires login)
@login_required
def edit_todo(request, id):
    todo = get_object_or_404(Todo, id=id, user=request.user)  # Ensure user owns the task
    if request.method == 'POST':
        form = TodoForm(request.POST, instance=todo)
        if form.is_valid():
            form.save()
            return redirect('todo_list')
    else:
        form = TodoForm(instance=todo)
    return render(request, 'todo/edit_todo.html', {'form': form})

# Delete a task (requires login)
@login_required
def delete_todo(request, id):
    todo = get_object_or_404(Todo, id=id, user=request.user)  # Ensure user owns the task
    if request.method == 'POST':
        todo.delete()
        return redirect('todo_list')
    return render(request, 'todo/delete_todo.html', {'todo': todo})

# Toggle Task Completion (requires login)
@login_required
def toggle_complete(request, id):
    todo = get_object_or_404(Todo, id=id, user=request.user)  # Ensure user owns the task
    todo.completed = not todo.completed
    todo.save()
    return redirect('todo_list')
